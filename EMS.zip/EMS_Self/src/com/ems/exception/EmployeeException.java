package com.ems.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7175096869854698095L;

	public EmployeeException(String message) {
		super(message);
	}
}
