package com.ems.dao;

import java.util.List;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

public interface IEmployeeDao {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException;
	
	public boolean deleteEmployee(int employeeId) throws EmployeeException;
	
	public boolean updateEmployee(int employeeId, EmployeeBean employee) throws EmployeeException;
	
	public EmployeeBean getEmployeeDetails(int employeeId) throws EmployeeException;
}
