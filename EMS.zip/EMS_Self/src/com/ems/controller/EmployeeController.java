package com.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;
import com.ems.service.IEmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	private IEmployeeService employeeService;
	
	@RequestMapping("showAll")
	public ModelAndView showAllEmployees()
	{
		ModelAndView mv=new ModelAndView();
		try {
			List<EmployeeBean> list=employeeService.viewAllEmployees();
			mv.setViewName("viewAll");
			mv.addObject("list", list);
		} catch (EmployeeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		
		return (mv);
	}
	
	@RequestMapping("showHomePage")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping(value="addEmployee", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("emp") EmployeeBean bean, BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		}
		
		else
		{
			try {
				int id = employeeService.addEmployee(bean);
				mv.setViewName("success");
				mv.addObject("id", id);
				mv.addObject("emp", bean);
			} catch (EmployeeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		}
		return(mv);
	}
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public ModelAndView search(@RequestParam("empId") int empId) {
		System.out.println("Recieved VALUE : " + empId);
		ModelAndView mv = new ModelAndView();
				EmployeeBean employee;
				try {
					employee = employeeService.getEmployeeDetails(empId);
					mv.addObject("emp", employee);
					mv.setViewName("display");
				} catch (EmployeeException e) {
					mv.addObject("message", e.getMessage());
					mv.setViewName("error");
				}
				
		
		return mv;
	}
	
	@RequestMapping("deleteEmployee")
	public ModelAndView deleteEmployee(@RequestParam("id") int empId) {
		ModelAndView mv = new ModelAndView();
		try {
			boolean isDeleted = employeeService.deleteEmployee(empId);
			if (isDeleted) {
				List<EmployeeBean> list = employeeService.viewAllEmployees();
				mv.setViewName("viewAll");
				mv.addObject("list", list);
			}
		} catch (EmployeeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return mv;
	}
	
	@RequestMapping("updateEmployee")
	public ModelAndView showUpdateEmployee(@RequestParam("id") int empId, @RequestParam("name") String empName, @RequestParam("salary") double empSalary) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateEmployee");
		mv.addObject("id", empId);
		mv.addObject("name", empName);
		mv.addObject("salary", empSalary);
		System.out.println(empName);
		return mv;
	}
	
	@RequestMapping("updateEmp")
	public ModelAndView updateEmployee(
			@ModelAttribute("emp") EmployeeBean bean, BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed ");
		} else {
			try {
				boolean isUpdated = employeeService.updateEmployee(
						bean.getEmployeeId(), bean);
				if (isUpdated) {
					mv.setViewName("updateSuccess");
				}

			} catch (EmployeeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		}
		return mv;
	}
	
	@RequestMapping("inputid")
	public String searchId(){
		
		return "inputidform";
	}
}
