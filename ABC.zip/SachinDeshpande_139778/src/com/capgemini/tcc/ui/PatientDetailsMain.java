package com.capgemini.tcc.ui;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientDetailsBean;
import com.capgemini.tcc.exception.PatientDetailsException;
import com.capgemini.tcc.service.ServicePatientDetailsImpl;


public class PatientDetailsMain {
private static Logger logger=Logger.getRootLogger();
	
	public static void main(String[] args){
		PropertyConfigurator.configure("resources/log4j.properties");
		boolean isInProcess = true;
		boolean isValid = false;
		byte choice=0;
		
		String pName = null;
		int pAge = 0;
		String phoneNo = null;
		String pDesc = null;
		
		List<PatientDetailsBean>patientList;
		
		ServicePatientDetailsImpl servicePatientDetails = new ServicePatientDetailsImpl();
		
		PatientDetailsBean patientDetailsBean = null;
		
		Scanner scInput = new Scanner(System.in);
		
		while(isInProcess){
			
			System.out.println("1. Add Patient Information.");
			System.out.println("2. Search Patient by Id.");
			System.out.println("3. Exit.");
			
			choice = Byte.parseByte(scInput.nextLine());
			
			switch(choice){
			case 1: 
				while(!isValid){
					try{
						System.out.println("Enter The Name of Patient: ");
						cname = scInput.nextLine();
						isValid = servicePatientDetails.isValidpName(pName);
						
					}
					catch( PatientDetailsException mpe){
						logger.error("Invalid Name: " + pName);
						System.err.println("Invalid name: " +pName);
						isValid = false;
					}
				}
				isValid = false;
				while(!isValid){
					try{
						System.out.println("Enter Patient Age : ");
						pAge = scInput.nextLine();
						isValid = servicePatientDetails.isValidAge(pAge);
				
					}
					catch( PatientDetailsException mpe){
						logger.error("Invalid Age: " + pAge);
						isValid = false;
					}
				}
				isValid = false;
				while(!isValid){
					try{
						System.out.println("Enter Patient Phone Number : ");
						phoneNo = scInput.nextLine();
						isValid = servicePatientDetails.isValidPhoneNo(phoneNo);
				
					}
					catch( PatientDetailsException mpe){
						logger.error("Invalid phone: " + phoneNo);
						isValid = false;
					}
				}
				isValid = false;
				while(!isValid){
					try{
						System.out.println("Enter Description :");
						pDesc=Integer.parseInt(scInput.nextLine());
						isValid = servicePatientDetails.isValidDesc(pDesc);
					
					}
					catch( PatientDetailsException mpe){
						logger.error("Invalid description: " + pDesc);
						isValid = false;
					}
				}
				
				
				patientDetailsBean = new PatientDetailsBean(pName, pAge, phoneNo, pDesc);
				try 
				{
					servicePatientDetails.insertPatientDetails(patientDetailsBean);
				} 
				catch (PatientDetailsException e) 
				{
					logger.error(e.getMessage());
					e.printStackTrace();
				}
				break;
			 			
			case 2:
				int pid=0;
				
				System.out.println("Enter Patient Id: ");
				
				pid= scInput.nextInt();
				
				try
				{
					
				
				patientList = ServicePatientDetailsImpl.search(pid);
				
				if (empList!=null) {
					for (EmployeeBean EmployeeBean : empList){
						System.out.println(EmployeeBean);
					}
				} else {
					System.out.println("No employee found");
				}	
				
					System.out.println("====================================================================");
				}catch(EmployeeException e){
					System.err.print("No records found");
					logger.error(e.getMessage());
				}
				
				break;
				
				
				default: 
				System.out.println("Invalid Input!!");
				break;
				
			}
			
		}
	}

}
