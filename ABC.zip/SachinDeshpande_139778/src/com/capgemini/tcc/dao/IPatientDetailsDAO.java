package com.capgemini.tcc.dao;

import java.util.List;
import com.capgemini.tcc.bean.PatientDetailsBean;
import com.capgemini.tcc.exception.PatientDetailsException;

public interface IPatientDetailsDAO {

	public int insertPatient(PatientDetailsBean patientDetailsBean)
			throws PatientDetailsException;
	
	public List<PatientDetailsBean> search(final int patient_id)
			throws PatientDetailsException;
	
}
