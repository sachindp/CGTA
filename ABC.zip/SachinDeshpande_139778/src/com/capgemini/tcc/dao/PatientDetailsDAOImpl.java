package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.tcc.bean.PatientDetailsBean;
import com.capgemini.tcc.exception.PatientDetailsException;
import com.capgemini.tcc.util.DBConnection;

public class PatientDetailsDAOImpl implements IPatientDetailsDAO {

@Override
public int insertPatient(PatientDetailsBean patientDetailsBean)
throws PatientDetailsException {
			
int records=0;
		
int patient_id=0;
		
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=connPurchaseDetails.prepareStatement(QueryMapperPatientDetails.INSERT_PATIENT)
					)
					{
					java.sql.Date consulDate = new Date(new java.util.Date().getTime());
					
					preparedStatement.setString(1, patientDetailsBean.getPatName());
					preparedStatement.setInt(2, patientDetailsBean.getPatAge());
					preparedStatement.setString(3, patientDetailsBean.getPatPhoneNo());		
					preparedStatement.setString(4, patientDetailsBean.getPatDesc());	
					preparedStatement.setDate(5, consulDate);
					
					
					records = preparedStatement.executeUpdate();
					
					if(records > 0)
						{
							isInserted = true;
						}
					}
					
		catch(SQLException sqlEx)
		{
					throw new PatientDetailsException(sqlEx.getMessage());
		}
		return isInserted;
	}


	@Override
	public List<PatientDetailsBean> search(int patient_id)
			throws PatientDetailsException {

			List<PatientDetailsBean>patientList=new ArrayList<PatientDetailsBean>();
			try(Connection connpatient = DBConnection.getInstance().getConnection();	
				
					PreparedStatement preparedStatement=connpatient.prepareStatement(QueryMapperPatientDetails.SEARCH_PATIENT);
				)
				{
				preparedStatement.setFloat(1, patient_id);
				
				ResultSet rsPatient=preparedStatement.executeQuery();
			    		
				while(rsPatient.next())
					{
						PatientDetailsBean patient=new PatientDetailsBean();
					
						patient.setPatName("patient_name");
						patient.setPatAge(rsPatient.getInt("age"));
						patient.setPatPhoneNo("phone");
						patient.setPatDesc("description");
						patient.setConsulDate(rsPatient.getDate("consultation_date"));
					
						patientList.add(patient);
					}
				
				if(patientList.size()==0)
				{
					throw new PatientDetailsException("NO RECORDS FOUND");
				}
				}			
				catch(SQLException sqlEx)
				{
						throw new PatientDetailsException(sqlEx.getMessage());
				}
		return patientList;
	}

}
