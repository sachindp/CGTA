package com.capgemini.tcc.exception;

public class PatientDetailsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6045527792311555642L;

	public PatientDetailsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientDetailsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
