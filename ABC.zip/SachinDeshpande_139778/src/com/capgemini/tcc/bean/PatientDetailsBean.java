package com.capgemini.tcc.bean;

import java.sql.Date;


public class PatientDetailsBean {
	private int patId;
	private String patName;
	private int patAge;
	private String patPhoneNo;
	private String patDesc;
	private Date consulDate;
	public PatientDetailsBean() {
		super();
	}
	public PatientDetailsBean(int patId, String patName, int patAge,
			String patPhoneNo, String patDesc, Date consulDate) {
		super();
		this.patId = patId;
		this.patName = patName;
		this.patAge = patAge;
		this.patPhoneNo = patPhoneNo;
		this.patDesc = patDesc;
		this.consulDate = consulDate;
	}
	public int getPatId() {
		return patId;
	}
	public void setPatId(int patId) {
		this.patId = patId;
	}
	public String getPatName() {
		return patName;
	}
	public void setPatName(String patName) {
		this.patName = patName;
	}
	public int getPatAge() {
		return patAge;
	}
	public void setPatAge(int patAge) {
		this.patAge = patAge;
	}
	public String getPatPhoneNo() {
		return patPhoneNo;
	}
	public void setPatPhoneNo(String patPhoneNo) {
		this.patPhoneNo = patPhoneNo;
	}
	public String getPatDesc() {
		return patDesc;
	}
	public void setPatDesc(String patDesc) {
		this.patDesc = patDesc;
	}
	public Date getConsulDate() {
		return consulDate;
	}
	public void setConsulDate(Date consulDate) {
		this.consulDate = consulDate;
	}
	@Override
	public String toString() {
		return "PatientDetailsBean [patId=" + patId + ", patName=" + patName
				+ ", patAge=" + patAge + ", patPhoneNo=" + patPhoneNo
				+ ", patDesc=" + patDesc + ", consulDate=" + consulDate + "]";
	}

}