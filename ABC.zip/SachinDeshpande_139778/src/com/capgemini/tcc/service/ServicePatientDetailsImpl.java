package com.capgemini.tcc.service;

import java.util.List;

import com.capgemini.tcc.bean.PatientDetailsBean;
import com.capgemini.tcc.dao.IPatientDetailsDAO;
import com.capgemini.tcc.dao.PatientDetailsDAOImpl;
import com.capgemini.tcc.exception.PatientDetailsException;

public class ServicePatientDetailsImpl implements IServicePatientDetails {

	IPatientDetailsDAO patientDetailsDAO = new PatientDetailsDAOImpl();
	
	@Override
	public int insertPatient(PatientDetailsBean patientDetailsBean)
			throws PatientDetailsException {
		int patientId = 0;
		
		try {
			patientId = patientDetailsDAO.insertPatient(patientDetailsBean);
		} 
		catch (PatientDetailsException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return patientId;
	}

	@Override
	public List<PatientDetailsBean> search(int patient_id)
			throws PatientDetailsException {

		List<PatientDetailsBean> patientlist = patientDetailsDAO.search(patient_id);
		
		return patientlist;
	}


}
