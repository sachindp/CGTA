package com.cg.customer.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.customer.bean.Customer;
import com.cg.customer.exception.CustomerException;

@Repository
@Transactional
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addComplaint(Customer customer) throws CustomerException {
		int id=0;
		try
		{
			entityManager.persist(customer);
			entityManager.flush();
			id=customer.getComplaintid();
		}
		catch(Exception e)
		{
			throw new CustomerException("Unable to Persist " + e.getMessage());
		}
		return id;
	}

	@Override
	public Customer getComplaint(int complaintid) throws CustomerException {
		Customer customer = null;
		try
		{
			customer=entityManager.find(Customer.class, complaintid);			
		}
		catch(Exception e)
		{
			throw new CustomerException("Couldn't Find Complaint For This Id " +complaintid+ e.getMessage());
		}
		return customer;
	}

}
