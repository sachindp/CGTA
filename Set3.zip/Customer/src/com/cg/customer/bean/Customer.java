package com.cg.customer.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="complaint")
public class Customer {
	
	@Id
	@Column
	@GeneratedValue
	private int complaintid;
	@Column
	private int accountid;
	@Column
	private String branchcode;
	@Column
	private String emailid;
	@Column
	private String category;
	@Column
	private String description;
	@Column
	private String priority;
	@Column
	private String status;
	
	public Customer() {
		super();
	}

	public Customer(int complaintid, int accountid, String branchcode,
			String emailid, String category, String description,
			String priority, String status) {
		super();
		this.complaintid = complaintid;
		this.accountid = accountid;
		this.branchcode = branchcode;
		this.emailid = emailid;
		this.category = category;
		this.description = description;
		this.priority = priority;
		this.status = status;
	}

	public int getComplaintid() {
		return complaintid;
	}

	public void setComplaintid(int complaintid) {
		this.complaintid = complaintid;
	}

	public int getAccountid() {
		return accountid;
	}

	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}

	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
