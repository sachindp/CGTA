package com.capgemini.mobipur.bean;

import java.time.LocalDate;

public class PurchaseDetailsBean {
	private int purchaseId;
	private String name;
	private String mailId;
	private String phoneNo;
	private LocalDate purDate;
	private int mobileId;
	
	public PurchaseDetailsBean() {
		super();
	}
	
	public PurchaseDetailsBean(int purchaseId, String name, String mailId,
			String phoneNo, LocalDate purDate, int mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.name = name;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purDate = purDate;
		this.mobileId = mobileId;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public LocalDate getPurDate() {
		return purDate;
	}

	public void setPurDate(LocalDate purDate) {
		this.purDate = purDate;
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	@Override
	public String toString() {
		return "PurchaseDetailsBean [purchaseId=" + purchaseId + ", name="
				+ name + ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purDate=" + purDate + ", mobileId=" + mobileId + "]";
	}
	
	
}
