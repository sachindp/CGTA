CREATE OF REPLACE PROCEDURE book_details(
	v_book_code IN NUMBER,
	v_student_code IN NUMBER,
	dated OUT VARCHAR2
)
IS 

BEGIN

	dated := SYSDATE + 10;
	
END;
/