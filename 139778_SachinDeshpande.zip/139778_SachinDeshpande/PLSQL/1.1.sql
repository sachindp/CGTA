DECLARE
	V_Sample1 NUMBER(2);
	V_Sample2 CONSTANT NUMBER(2) ;
	V_Sample3 NUMBER(2) NOT NULL ;
	V_Sample4 NUMBER(2) := 50;
	V_Sample5 NUMBER(2) DEFAULT 25;

BEGIN
	DBMS_OUTPUT.PUT_LINE('hello');
END;
/

--answer

--v_sample2 variable must be initialized
--v_sample3 variable must be initialized 