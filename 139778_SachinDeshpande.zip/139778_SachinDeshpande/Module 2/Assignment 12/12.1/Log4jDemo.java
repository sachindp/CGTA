package com.Q12.A1.sample;

import org.apache.log4j.Logger;

public class Log4jDemo {
//create a logger for Log4jDemo class
public static void main(String args[]) {
// create log messages for each priority level
}
}