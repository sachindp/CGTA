package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class ServiceMain {

	public static void main(String[] args) {
		
		Service service = new Service();
		Employee employee = new Employee();
		
		service.getEmployeeDetails(employee);
		service.setInsuranceScheme(employee);
		service.showEmployeeDetails(employee);

	}

}
