public class PersonDetails {

	public static void main(String[] args) {
		
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name: SACHIN");
		System.out.println("Last Name: DESHPANDE");
		System.out.println("Gender: M");
		System.out.println("Age: 22");
		System.out.println("Weight: 54.50");

	}
}