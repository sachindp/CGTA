public class Person {
	private String fName;
	private String lName;
	private char gend;
	private long phNo;
	
	//Default Constructor
	public Person(){
		
	}
		
	//Parameterized Constructor
	public Person(String fName, String lName, char gend) {
		this.fName = fName;
		this.lName = lName;
		this.gend = gend;
	} 
	
	//Getter and Setter
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public char getgend() {
		return gend;
	}
	public void setgend(char gend) {
		this.gend = gend;
	}
	
	public void setphNo(long num){
		this.phNo=num;
	}
	public void output(){
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name: "+fName);
		System.out.println("Last Name: "+lName);
		System.out.println("gend: "+gend);
		System.out.println("Phone Number: "+phNo);
	}
}