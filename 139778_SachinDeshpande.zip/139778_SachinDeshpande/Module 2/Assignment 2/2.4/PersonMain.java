public class PersonMain {

	public static void main(String[] args) 
	{
		
		String fName;
		String lName;
		char gend;
		long phNo;
		
		Scanner scInput = new Scanner(System.in);
		
		Person person = new Person("Sachin","Deshpande",'M');
		
		System.out.println("Enter your mobile number");
		phNo=scInput.nextLong();
					scInput.nextLine();
		
		person.setPhoneNumber(phNo);
		
		person.output();
	}
}