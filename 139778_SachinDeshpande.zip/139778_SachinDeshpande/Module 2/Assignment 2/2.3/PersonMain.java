public class PersonMain 
{

	public static void main(String[] args) 
	{
		
		String fName;
		String lName;
		char gender;
		
		Person person = new Person("Sachin","Deshpande",'M');
		
		person.output();
	}
}