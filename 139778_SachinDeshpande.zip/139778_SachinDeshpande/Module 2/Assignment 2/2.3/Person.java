public class Person 
{
	private String fName;
	private String lName;
	private char gender;
	
	//Default Constructor
	public Person(){
		
	}
		
	
	public Person(String fName, String lName, char gender) 
	{
		this.fName = fName;
		this.lName = lName;
		this.gender = gender;
	} 
	
	
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public void output(){
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name: "+fName);
		System.out.println("Last Name: "+lName);
		System.out.println("Gender: "+gender);
	}
}