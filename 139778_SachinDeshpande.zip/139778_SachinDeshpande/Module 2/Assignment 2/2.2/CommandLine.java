public class CommandLine {

	public static void main(String[] args) 
{
		int number;

		number = Integer.parseInt(args[0]);

		if(number > 0)
		{
			
				System.out.println(number +" is a POSITIVE integer.");
		}
		else
		{
				System.out.println(number +" is a NEGATIVE number.");
		}

	}

}