import java.util.Arrays;


public class StringSort {

	public static void main(String[] args) {

		String products[]={"Pen","Pencil","Book","Eraser","Notebook"};
		Arrays.sort(products);
		for (int i = 0; i < products.length; i++) {
			System.out.println(products[i]);
		}
		
	}

}
