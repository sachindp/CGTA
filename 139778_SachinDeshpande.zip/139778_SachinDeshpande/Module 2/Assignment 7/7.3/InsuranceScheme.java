public enum InsuranceScheme {
	SchemeA,SchemeB,SchemeC,NoScheme
}
