
public class Account {
	private long accountNum;
	private double bal;
	private Person accHold;
	private static long ind=0;
	
	//Default Constructor
	public Account() {
	}
	
	//Parameterized Constructor
	public Account(double bal, Person accHold) {
		ind++;
		this.accountNum = ind;
		this.bal = bal;
		this.accHold = accHold;
	}


	//Getter and Setter
	public double getbal() {
		return bal;
	}
	public void setbal(double bal) {
		this.bal = bal;
	}
	public Person getaccHold() {
		return accHold;
	}
	public void setaccHold(Person accHold) {
		this.accHold = accHold;
	}
	
	//Deposit Function
	public void deposit(double amount){
		this.bal=this.bal+amount;
	}
	
	//Withdraw Function
	public boolean withdraw(double amount){
		this.bal=this.bal-amount;
		return true;
	}

	//toString Function
	public String toString(){
		String text = "Account Number: " +accountNum + "\n" +
						"bal: "+bal + "\n" +
						"Holder Name: "+accHold.getFirstName() + "\n" +
					  "===========================================================\n";
		return text;
	}
}
