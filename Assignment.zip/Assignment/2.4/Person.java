public class Person {
	private String firstName;
	private String lastName;
	private char gender;
	private long phoneNumber;
	
	//Default Constructor
	public Person(){
		
	}
		
	//Parameterized Constructor
	public Person(String firstName, String lastName, char gender) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	} 
	
	//Getter and Setter
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public void setPhoneNumber(long num){
		this.phoneNumber=num;
	}
	public void output(){
		System.out.println("Person Details");
		System.out.println("-------------------");
		System.out.println("First Name: "+firstName);
		System.out.println("Last Name: "+lastName);
		System.out.println("Gender: "+gender);
		System.out.println("Phone Number: "+phoneNumber);
	}
}