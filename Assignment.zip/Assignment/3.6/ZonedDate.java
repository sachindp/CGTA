import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZonedDate {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose Of which zone you want to find date: ");
		System.out.println("1. America/New_York");
		System.out.println("2. Europe/London");
		System.out.println("3. Asia/Tokyo");
		System.out.println("4. US/Pacific");
		System.out.println("5. Africa/Cairo");
		System.out.println("6. Australia/Sydney");
		System.out.println("Enter your choice in numbers: ");
		int choice = sc.nextInt();
		
		ZonedDateTime currentTime = ZonedDateTime.now();
		switch(choice){
		case 1:
			currentTime=currentTime.withZoneSameInstant(ZoneId.of("America/New_York"));
			break;
		case 2:
			currentTime=currentTime.withZoneSameInstant(ZoneId.of("Europe/London"));
			break;
		case 3:
			currentTime=currentTime.withZoneSameInstant(ZoneId.of("Asia/Tokyo"));
			break;
		case 4:
			currentTime=currentTime.withZoneSameInstant(ZoneId.of("US/Pacific"));
			break;
		case 5:
			currentTime=currentTime.withZoneSameInstant(ZoneId.of("Africa/Cairo"));
			break;
		case 6:
			currentTime=currentTime.withZoneSameInstant(ZoneId.of("Australia/Sydney"));
			break;
		default:
			System.out.println("Please choose correctly");
			break;
		}
		System.out.println("According to your choosen zone time is "+currentTime);
		
		sc.close();
	}

}